
const dec = 15; //maximum size of the random number - also number of quotes to display
// we can generate 0 as a random number but not dec value itself as random() generates 0->1 but not 1 itself.
// improve by having more quotes

var quoteArray = ["Never, never, never give up.", "You have enemies? Good. That means you've stood up for something, sometime in your life.", "Attitude is a little thing that makes a big difference.", "All great things are simple, and many can be expressed in single words: freedom, justic, honor, duty, mercy, hope.", "The best argument against democracy is a five-minute conversation with the average voter.", "To improve is to change, so to be perfect is to have changed often.", "Success consists of going from failure to failure without losing enthousiasm!", "Now this is not the end. Its not even the beggining of the end. But it is, perhaps, the end of the beggining.", "We shape our buildings; thereafter they shape us.", "To improve is to change, so to be perfect is to have changed often.", "Continuous effort - not strength or intelligence - is the key to unlocking our potential.","The farther backward you can look, the farther forward you are likely to see.","It is a good thing for an uneducated an to read books of quotations!", "There are a terrible lot of lies going about the world, and the worst of it is that half of them are true.","The price of greatness is responsibility."];
var i = 0;

function randomizedIndex() {
    i = Math.floor(Math.random() * dec);
    return i;
}

function generateQ() {
    randomizedIndex();
    console.log(randomizedIndex());


    document.getElementById("quoteBox").innerHTML = quoteArray[i];
}
