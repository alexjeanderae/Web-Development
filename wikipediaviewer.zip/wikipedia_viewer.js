
$("#searchButton").on("click", function () {
    var searchValue = $("#searchBar").val();
   
    //url is a stored value and this is the right way to concatenate
    var url = "https://en.wikipedia.org/w/api.php?action=opensearch&search=" + searchValue + "&callback=?";
    //to display the info - add a div that will be changed by jQuery
    console.log(url);
    console.log(searchValue);
       $.ajax({
        url: url,
        type: "GET",
        async: false,
        dataType: "json",
        success: function (data, status, jqXHR) {
            console.log(data);
            $("#resultShown").html(""); // ajax is done - before presenting the results on screen wipes the exisiting content on screen if any
            for (var i = 0; i < data[1].length; i++) {


                $('#resultShown').append("<div><a target='blank' href=" + data[3][i] + "><h2>" + data[1][i] + "</h2></a>" + "<p>" + data[2][i] + "</p></div><hr>");


            } //for loop ends
            $("#searchTerm").val("");
        }, //success function ends
        error: function (error) {
            alert("error");
        }
      }) // ajax ends
   
}) //onclick ends
