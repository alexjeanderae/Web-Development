
console.log("JS loaded");

$("#longLatManual").on("click", function () {
    console.log("Manual input Coord");
    var long = $("#longInput").val();
    var lat = $("#latInput").val();
    console.log(lat + "  " + long);
    if (long == 0 && lat == 0) { alert("Error - missing coordinate or both == 0"); }
    // avoids missing a field and having 0 as default long or lat - could add also elif later to account for more false input by the user
    else {

        var url = "https://fcc-weather-api.glitch.me/api/current?lat=" + lat + "&lon=" + long;
        console.log(url);
        getMeteo(url);
    }
}); //end of onclick function

$("#GeoLongLatFind").on("click", function () {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            $("#canBeReplaced").html("Latitude: " + Math.floor(position.coords.latitude) + "<br>Longitude: " + Math.floor(position.coords.longitude));
            var long = position.coords.longitude;
            var lat = position.coords.latitude;
            console.log(lat + "    " + long);
            var url = "https://fcc-weather-api.glitch.me/api/current?lat=" + lat + "&lon=" + long;
            console.log(url);
            getMeteo(url);
        });
      
    }
    else {
         alert("Geolocation is not supported by this browser.");
    }

});//ends on clickfunction for geolocation finder


function getMeteo(targetUrl) {
    console.log("API on: " + targetUrl);
    $.ajax ({
        url: targetUrl,
        type: "GET",
        async: false,
        datatype:"json",
        success: function (data, status, jqXHR) {
            console.log(data);
            toScreen(data);
        }//end of success
    }) // end of Ajax GET
}

function toScreen(data) {
    console.log(data);
   $("#iconToShow").html("<img src='" + data.weather[0].icon +"'></img>");
    console.log(data.weather[0].icon);
    $("#temperatureToShow").html(data.main.temp + "&#8451");
    $("#toggleTemp").html("<button id='toggleTempButton'>Convert to F</button>")
    $("#toggleTempButton").click(function () {
        console.log("clicked");
        var farh = Math.floor(data.main.temp * 1.8 + 32);
        console.log(farh);
        $("#temperatureToShow").html(farh + "&#8457");
        $("#toggleTempButton").hide();
    })//end of conversion button
}//end of toScreen

